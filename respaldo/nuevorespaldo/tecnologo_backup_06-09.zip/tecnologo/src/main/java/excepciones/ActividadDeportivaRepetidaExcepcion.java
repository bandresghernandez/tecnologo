package excepciones;

public class ActividadDeportivaRepetidaExcepcion extends Exception{
	private static final long serialVersionUID = 1L;

	public ActividadDeportivaRepetidaExcepcion(String string) {
        super(string);
    }
}
