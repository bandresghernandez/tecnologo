package excepciones;

public class UsuarioEnUsoExcepcion extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public UsuarioEnUsoExcepcion(String string) {
		super(string);
	}

}
